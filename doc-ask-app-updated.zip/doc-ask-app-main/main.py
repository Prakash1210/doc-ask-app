from fastapi import FastAPI
from backend.database import Base, engine
from backend.auth import routes as auth_routes
from backend.chat import routes as chat_routes

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Doc Ask App with User Management")

app.include_router(auth_routes.router)
app.include_router(chat_routes.router)


# Integrated document reader routes
from backend import routes_doc
app.include_router(routes_doc.router, prefix='/api')
