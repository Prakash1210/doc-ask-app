import os
from uuid import uuid4
from pdfminer.high_level import extract_text

# Minimal document ingestion utilities.
BASE_DIR = os.path.dirname(__file__)
STORAGE_DIR = os.path.join(BASE_DIR, 'storage')
INDEX_DIR = os.path.join(BASE_DIR, 'indexes')
os.makedirs(STORAGE_DIR, exist_ok=True)
os.makedirs(INDEX_DIR, exist_ok=True)

def save_uploaded_file(uploaded_bytes, filename):
    doc_id = str(uuid4())
    path = os.path.join(STORAGE_DIR, f"{doc_id}_{filename}")
    with open(path, 'wb') as f:
        f.write(uploaded_bytes)
    return doc_id, path

def extract_text_from_pdf(path):
    try:
        text = extract_text(path)
        return text
    except Exception as e:
        raise RuntimeError(f"Failed to extract text: {e}")

# Placeholder functions for embedding/indexing - implement with OpenAI + FAISS
def create_index_for_document(doc_id, text, index_path=None):
    # This function should:
    # 1. chunk text
    # 2. call embeddings API (OpenAI or similar)
    # 3. store vectors into FAISS index and persist index to index_path
    # Here we only persist the raw text as a simple fallback.
    if not index_path:
        index_path = os.path.join(INDEX_DIR, f"{doc_id}.txt")
    with open(index_path, 'w', encoding='utf-8') as f:
        f.write(text)
    return {"index_path": index_path, "length": len(text)}

def load_index_placeholder(doc_id):
    index_path = os.path.join(INDEX_DIR, f"{doc_id}.txt")
    if not os.path.exists(index_path):
        raise FileNotFoundError("Index not found")
    with open(index_path, 'r', encoding='utf-8') as f:
        return f.read()
