from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from .doc_reader import save_uploaded_file, extract_text_from_pdf, create_index_for_document, load_index_placeholder
router = APIRouter()

@router.post('/upload')
async def upload_file(file: UploadFile = File(...)):
    try:
        content = await file.read()
        doc_id, path = save_uploaded_file(content, file.filename)
        text = extract_text_from_pdf(path) if file.filename.lower().endswith('.pdf') else content.decode('utf-8', errors='ignore')
        meta = create_index_for_document(doc_id, text)
        return JSONResponse({"doc_id": doc_id, "filename": file.filename, "meta": meta})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get('/documents')
async def list_documents():
    # list saved documents in storage
    import os
    from pathlib import Path
    storage = Path(__file__).parent / 'storage'
    files = []
    if storage.exists():
        for f in storage.iterdir():
            files.append(f.name)
    return {"documents": files}

@router.post('/doc-question')
async def ask_document(doc_id: str, question: str):
    # placeholder QA: loads raw text and returns a naive answer (search for keywords)
    try:
        text = load_index_placeholder(doc_id)
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))
    # naive retrieval: return first 500 chars containing any keyword from question
    keywords = [w.lower() for w in question.split() if len(w)>3]
    snippet = ''
    for kw in keywords:
        idx = text.lower().find(kw)
        if idx!=-1:
            start = max(0, idx-200)
            snippet = text[start:start+700].replace('\n',' ')
            break
    if not snippet:
        snippet = text[:700].replace('\n',' ')
    answer = f"(NAIVE) Based on document: {snippet}..."
    return {"answer": answer}
