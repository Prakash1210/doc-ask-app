from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from utils import save_uploaded_file, extract_text_from_file, create_index_for_document, list_documents, search_document_context
import os

router = APIRouter()

@router.post('/upload')
async def upload_file(file: UploadFile = File(...)):
    try:
        content = await file.read()
        doc_id, path = save_uploaded_file(content, file.filename)
        text = extract_text_from_file(path)
        meta = create_index_for_document(doc_id, text)
        return JSONResponse({'doc_id': doc_id, 'filename': file.filename, 'meta': meta})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get('/documents')
async def get_documents():
    docs = list_documents()
    return {'documents': docs}

class ChatPayload(BaseModel):
    message: str | None = None
    doc_id: str | None = None
    question: str | None = None

@router.post('/chat')
async def chat(payload: ChatPayload):
    # If doc_id + question provided, search document context and return combined response
    if payload.doc_id and payload.question:
        context = search_document_context(payload.doc_id, payload.question)
        # Naive response: echo context + short answer stub
        answer = f"(Document-aware) Found context:\n{context[:800]}\n\nAnswer (stub): This is a short answer based on the document context."
        return {'answer': answer, 'sources': [{'doc_id': payload.doc_id}]}
    elif payload.message:
        # Plain chat stub
        return {'answer': f"(Chat) Echo: {payload.message}"}
    else:
        raise HTTPException(status_code=400, detail='Provide message or doc_id+question')
