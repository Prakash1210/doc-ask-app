# Backend for Doc Ask App
Run `pip install -r requirements.txt` and `uvicorn main:app --reload`
