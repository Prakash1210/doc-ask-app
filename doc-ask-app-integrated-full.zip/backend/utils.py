import os
from uuid import uuid4
from pdfminer.high_level import extract_text as pdf_extract_text

BASE = os.path.dirname(__file__)
STORAGE = os.path.join(BASE, 'storage')
INDEXES = os.path.join(BASE, 'indexes')
os.makedirs(STORAGE, exist_ok=True)
os.makedirs(INDEXES, exist_ok=True)

def save_uploaded_file(content: bytes, filename: str):
    doc_id = str(uuid4())
    safe_name = filename.replace(' ', '_')
    path = os.path.join(STORAGE, f"{doc_id}_{safe_name}")
    with open(path, 'wb') as f:
        f.write(content)
    return doc_id, path

def extract_text_from_file(path: str) -> str:
    # Try PDF extraction for .pdf, otherwise decode as text
    low = path.lower()
    if low.endswith('.pdf'):
        try:
            text = pdf_extract_text(path)
            return text or ''
        except Exception as e:
            return ''
    else:
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception:
            return ''

def create_index_for_document(doc_id: str, text: str):
    # Simple index: store raw text to an index file for preview and naive search
    index_path = os.path.join(INDEXES, f"{doc_id}.txt")
    with open(index_path, 'w', encoding='utf-8') as f:
        f.write(text)
    return {'index_path': index_path, 'length': len(text)}

def list_documents():
    files = []
    for p in os.listdir(STORAGE):
        files.append(p)
    return files

def search_document_context(doc_id: str, question: str) -> str:
    # Naive keyword search: find first occurrence of any long word from question
    index_path = os.path.join(INDEXES, f"{doc_id}.txt")
    if not os.path.exists(index_path):
        raise FileNotFoundError('Document not indexed')
    text = ''
    with open(index_path, 'r', encoding='utf-8', errors='ignore') as f:
        text = f.read()
    keywords = [w.lower() for w in question.split() if len(w) > 3]
    for kw in keywords:
        idx = text.lower().find(kw)
        if idx != -1:
            start = max(0, idx-200)
            return text[start:start+800].replace('\n',' ')
    # fallback: return start of document
    return text[:800].replace('\n',' ')
