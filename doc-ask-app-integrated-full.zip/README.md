# Doc Ask App - Integrated (Full Stack)

This package includes a simple FastAPI backend and a React + Vite frontend with a split-screen UI:
- Left: Chat
- Right: Document Reader preview and upload

## Run backend
cd backend
python -m venv venv
# activate venv
pip install -r requirements.txt
uvicorn main:app --reload

## Run frontend
cd frontend
npm install
npm run dev
