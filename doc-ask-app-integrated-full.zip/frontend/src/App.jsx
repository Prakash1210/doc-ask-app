import React from 'react'
import ChatAndReader from './components/ChatAndReader'

export default function App(){
  return (
    <div style={{height:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'#f3f4f6'}}>
      <div style={{width: '95%', height: '90%', background:'#fff', boxShadow:'0 2px 10px rgba(0,0,0,0.08)', borderRadius:8, display:'flex', overflow:'hidden'}}>
        <ChatAndReader />
      </div>
    </div>
  )
}
