import React, {useState, useEffect, useRef} from 'react'
import axios from 'axios'

export default function ChatAndReader(){
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [documents, setDocuments] = useState([])
  const [selectedDoc, setSelectedDoc] = useState(null)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef()

  useEffect(()=>{ fetchDocs() }, [])

  async function fetchDocs(){
    try{
      const res = await axios.get('/api/documents')
      setDocuments(res.data.documents || [])
    }catch(e){
      console.error(e)
    }
  }

  async function handleUpload(e){
    const f = e.target.files[0]
    if(!f) return
    setUploading(true)
    const fd = new FormData()
    fd.append('file', f)
    try{
      const res = await axios.post('/api/upload', fd, { headers: {'Content-Type':'multipart/form-data'} })
      const doc_id = res.data.doc_id
      await fetchDocs()
      setSelectedDoc(doc_id)
    }catch(err){
      alert('Upload failed: ' + (err?.response?.data?.detail || err.message))
    }finally{
      setUploading(false)
      fileRef.current.value = null
    }
  }

  async function sendMessage(){
    if(!input) return
    const userMsg = {from:'user', text: input, id: Date.now()}
    setMessages(prev=>[...prev, userMsg])
    const payload = selectedDoc ? {doc_id: selectedDoc, question: input} : {message: input}
    setInput('')
    try{
      const res = await axios.post('/api/chat', payload)
      const bot = {from:'bot', text: res.data.answer || res.data.response || 'No response', sources: res.data.sources || [] , id: Date.now()+1}
      setMessages(prev=>[...prev, bot])
    }catch(err){
      const errMsg = {from:'bot', text: 'Error: '+ (err?.response?.data?.detail || err.message), id: Date.now()+2}
      setMessages(prev=>[...prev, errMsg])
    }
  }

  return (
    <div style={{display:'flex', width:'100%', height:'100%'}}>
      {/* Left: Chat */}
      <div style={{flex:1, borderRight:'1px solid #e5e7eb', display:'flex', flexDirection:'column', minWidth:0}}>
        <div style={{padding:16, borderBottom:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between'}}>
          <div style={{fontWeight:700}}>Unified Chat</div>
          <div style={{fontSize:12, color:'#6b7280'}}>Ask generally or select a document</div>
        </div>

        <div style={{flex:1, padding:16, overflowY:'auto', background:'#fafafa'}}>
          {messages.map(m=> (
            <div key={m.id} style={{marginBottom:12, textAlign: m.from==='user' ? 'right' : 'left'}}>
              <div style={{display:'inline-block', padding:10, borderRadius:8, maxWidth:'80%', background: m.from==='user' ? '#dcfce7' : '#f3f4f6', color:'#111'}}>{m.text}</div>
            </div>
          ))}
        </div>

        <div style={{padding:12, borderTop:'1px solid #e5e7eb', display:'flex', gap:8}}>
          <input value={input} onChange={e=>setInput(e.target.value)} placeholder={selectedDoc ? 'Ask about selected document...' : 'Ask anything...'} style={{flex:1, padding:10, border:'1px solid #e5e7eb', borderRadius:6}} />
          <button onClick={sendMessage} style={{padding:'10px 14px', background:'#2563eb', color:'#fff', border:'none', borderRadius:6}}>Send</button>
        </div>
      </div>

      {/* Right: Document sidebar */}
      <div style={{width:380, display:'flex', flexDirection:'column'}}>
        <div style={{padding:12, borderBottom:'1px solid #e5e7eb', display:'flex', alignItems:'center', justifyContent:'space-between'}}>
          <div style={{fontWeight:700}}>Document Reader</div>
          <div style={{fontSize:12, color:'#6b7280'}}>Upload & preview</div>
        </div>

        <div style={{padding:12, borderBottom:'1px solid #e5e7eb'}}>
          <input ref={fileRef} type="file" accept=".pdf,.txt" onChange={handleUpload} />
          {uploading && <div style={{marginTop:8,fontSize:13}}>Uploading...</div>}
        </div>

        <div style={{padding:12, overflowY:'auto'}}>
          <div style={{marginBottom:8, fontSize:13, color:'#374151'}}>Uploaded Documents</div>
          {documents.length===0 && <div style={{fontSize:13,color:'#6b7280'}}>No documents uploaded yet.</div>}
          {documents.map(d=> {
            const id = d.split('_')[0]
            return (
              <div key={d} style={{padding:8, borderRadius:6, marginBottom:8, background: selectedDoc===id ? '#eef2ff' : '#fff', border:'1px solid #e5e7eb', cursor:'pointer'}} onClick={()=>setSelectedDoc(id)}>
                <div style={{fontSize:13, fontWeight:600}}>{d}</div>
                <div style={{fontSize:12, color:'#6b7280'}}>{id}</div>
              </div>
            )
          })}
        </div>

        <div style={{padding:12, borderTop:'1px solid #e5e7eb', flex:1, overflowY:'auto'}}>
          <div style={{fontSize:13, fontWeight:700, marginBottom:8}}>Preview / Result</div>
          {!selectedDoc && <div style={{color:'#6b7280'}}>Select a document to see preview and ask document-specific questions.</div>}
          {selectedDoc &&
            <DocumentPreview docId={selectedDoc} />
          }
        </div>
      </div>
    </div>
  )
}

function DocumentPreview({docId}){
  const [loading, setLoading] = React.useState(true)
  const [text, setText] = React.useState('')

  React.useEffect(()=>{
    let mounted = true
    async function load(){
      setLoading(true)
      try{
        // ask preview question to the backend to fetch snippet
        const previewRes = await axios.post('/api/chat', {doc_id: docId, question: 'preview'})
        if(mounted){
          setText(previewRes.data.answer || 'No preview available')
        }
      }catch(err){
        setText('Preview not available.')
      }finally{
        setLoading(false)
      }
    }
    load()
    return ()=> mounted=false
  }, [docId])

  if(loading) return <div>Loading preview...</div>
  return <div style={{whiteSpace:'pre-wrap', fontSize:13, color:'#111'}}>{text}</div>
}
